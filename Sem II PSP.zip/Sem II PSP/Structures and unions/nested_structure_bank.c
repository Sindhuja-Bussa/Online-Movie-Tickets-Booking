#include<stdio.h>
struct account
{
	long long int account_number;
	char account_branch[10];
	char ifsc_code[10];	
};
struct bank
{
	char name[10];
	int amount;
	long long int contact_number;
	struct account b;
}d;
main()
{
	printf("enter bank details:\n");
	scanf("%s%d%lld%lld%s%s",d.name,&d.amount,&d.contact_number,&d.b.account_number,d.b.account_branch,d.b.ifsc_code);
	printf("\n \t \t Bank Details \t \t\n");
	printf("%s\n%d\n%lld\n%lld\n%s\n%s\n",d.name,d.amount,d.contact_number,d.b.account_number,d.b.account_branch,d.b.ifsc_code);
}
