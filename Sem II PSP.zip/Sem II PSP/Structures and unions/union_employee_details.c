#include<stdio.h>
union employee
{
	char name[10];
	int age;
	float salary;
}b;
main()
{
	printf("enter employee details:\n");
	printf("enter name:");
	scanf("%s",b.name);
	printf("%s\n",b.name);
	printf("enter age:");
	scanf("%d",&b.age);
	printf("%d\n",b.age);
	printf("enter salary:");
	scanf("%f",&b.salary);
	printf("%f\n",b.salary);
}
