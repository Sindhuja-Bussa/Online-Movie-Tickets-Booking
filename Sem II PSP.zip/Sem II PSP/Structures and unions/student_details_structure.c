#include<stdio.h>
struct student
{
	char name[10];
	int age;
	float marks;	
}; 
main()
{
	struct student s1;
	printf("\n ..........enter student details..........");
	scanf("%s %d %f",&s1.name,&s1.age,&s1.marks);
	printf("\tname \t age \t marks\n");
	printf("\t%s\t%d\t%f",s1.name,s1.age,s1.marks);
	printf("\n ..........thank you..........");	
}
