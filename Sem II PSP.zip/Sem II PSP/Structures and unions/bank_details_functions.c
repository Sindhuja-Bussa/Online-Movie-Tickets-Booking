#include<stdio.h>
int i;
struct bank
{
	char name[10];
	long long int account_number;
	char account_branch[10];
	char address[10];
	int amount;
	long long int contact_number;	
}e[10];
struct bank read(int);
struct bank del(int);
void display(struct bank[],int);
main()
{
	int n,ch,c;
	do
	{
		printf("1.Read\n2.Display\n3.Delete");
		printf("\nenter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter size:");
			       scanf("%d",&n);
			       printf("enter bank details:\n");
			       for(i=0;i<n;i++)
			       e[i]=read(i);
			       break;
			case 2:display(e,n);
			       break;
			case 3:e[i]=del(n);
			       display(e,n-1);
			       break;
		}
		printf("\n press 1 to continue:");
		scanf("%d",&c);
	}while(c==1);
}
struct bank read(int i)
{
	printf("CustomerName\nAccountNumber\nAccountBranch\naddress\namount\ncontact number");
	scanf("%s%lld%s%s%d%lld",e[i].name,&e[i].account_number,e[i].account_branch,e[i].address,&e[i].amount,&e[i].contact_number);
    return e[i];
}
void display(struct bank e[],int(n))
{
	printf("...........................Bank Details.....................\n");
	printf("CustomerName\nAccountNumber\nAccountBranch\naddress\namount\ncontact number");
	for(i=0;i<n;i++)
	printf("%s\n %lld \n %s \n %s \n %d \n %lld",e[i].name,e[i].account_number,e[i].account_branch,e[i].address,e[i].amount,e[i].contact_number);
}
struct bank del(int n)
{
	int pos;
	printf("enter position:");
	scanf("%d",&pos);
	for(i=pos-1;i<n;i++)
    e[i]=e[i+1];
}
