#include<stdio.h>
struct bank
{
	char name[10];
	int amount;
	long long int account_number;
	char ifsc_code[10];
	long long int contact_number;
};
main()
{
	struct bank *p,e;
	p=&e;
	printf("enter bank details:\n");
	scanf("%s%d%lld%s%lld",p->name,&p->amount,&p->account_number,p->ifsc_code,&p->contact_number);
	printf("\t \t Bank Details \t \t \n");
	printf("%s\n%d\n%lld\n%s\n%lld\n",p->name,p->amount,p->account_number,p->ifsc_code,p->contact_number);	
}
