#include<stdio.h>
struct distance
{
	int inch;
	int feet;	
}; 
main()
{
	struct distance d1,d2,sum;
	printf("......Enter First Distance.......\n");
	scanf("%d%d",&d1.feet,&d1.inch);
	printf("......Enter Second Distance.......\n");
	scanf("%d%d",&d2.feet,&d2.inch);
	sum.feet=d1.feet+d2.feet;
	sum.inch=d1.inch+d2.inch;
	while(sum.inch>12)
	{
		sum.inch=sum.inch-12;
		sum.feet++;
	}
	printf("sum of the distances:%d\t%d",sum.feet,sum.inch);
}
