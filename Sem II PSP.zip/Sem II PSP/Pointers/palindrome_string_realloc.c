#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,*q;
	int n1,n2,i,j=0,l1=0,count=1,flag=0;
	printf("enter size:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	for(i=0;i<n1;i++)
	scanf("%c",p+i);
	for(i=1;*(p+i)!='\0';i++)
	{
		l1++;
	}
	for(i=l1;i>=0;i--)
	{
	    *(p+j)=*(p+i);
	    j++;
    }
    *(p+j)='\0';
    for(i=1;i<l1;i++)
	{
		if(*(q+i)==*(p+i))
		count++;
	}
	if(count==l1)
	printf("palindrome");
	else
	printf("not a palindrome");
	flag=0,j=0;
	char str1[50];
	printf("\nEnter new size:");
	scanf("%d",&n2);
	p=(char *)realloc(p,n2*sizeof(char));
	for(i=0;i<n2;i++)
	scanf("%c",p+i);
	for(i=n2-1;i>=0;i--)
	{
	str1[j]=*(p+i);
	j++;
    }
    str1[j]='\0';
    p++;
   for(i=0;*(p+i)!='\0';i++)
	{
		if(*(p+i)!=str1[i])
		{
			flag=1;
		    break;
		}
	}
	if(flag==0)
	printf("Palindrome");
	else
	printf("Not a Palindrome");
	free(p);
}
