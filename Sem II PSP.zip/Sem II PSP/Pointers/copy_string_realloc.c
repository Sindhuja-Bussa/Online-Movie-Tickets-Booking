#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p,str[100];
	int n1,n2,i,j;
	printf("enter size:");
	scanf("%d",&n1);
	p=(char *)malloc(n1*sizeof(char));
	printf("enter the string:");
	for(i=0;i<n1;i++)
	scanf("%c",p+i);
    for(i=0;i<n1;i++)
    {
	str[i]=*(p+i);
    }
	puts(str);
	printf("\nenter resize:");
	scanf("%d",&n2);
	p=(char *)realloc(p,n2*sizeof(char));
    printf("enter the string:");
	for(i=0;i<n2;i++)
	scanf("%c",p+i);
    for(i=0;i<n2;i++)
    {
	str[i]=*(p+i);
	}
	puts(str);
	free(p);
}
