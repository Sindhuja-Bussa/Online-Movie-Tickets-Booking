#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p1,*p2;
	int a,b,c,d,i,count=0;
	printf("enter size:");
	scanf("%d",&a);
	p1=(char *)malloc(a*sizeof(char));
	printf("enter the main string:");
	for(i=0;i<a;i++)
	scanf("%c",p1+i);
	printf("enter size:");
	scanf("%d",&b);
	p2=(char *)malloc(b*sizeof(char));
	printf("enter the sub string:");
	for(i=0;i<b;i++)
	scanf("%c",p2+i);
	for(i=0;i<b;i++)
    {
	if(*(p1+i)==*(p2+i))
	   {
	    count++;
	   }
	}
	if(count==b)
	printf("substring is present");
	else 
	printf("substring is not present");
	count=0;
	printf("\nenter resize:");
	scanf("%d",&c);
	p1=(char *)realloc(p1,c*sizeof(char));
	printf("enter the main string:");
	for(i=0;i<c;i++)
	scanf("%c",p1+i);
	printf("enter resize:");
	scanf("%d",&d);
	p2=(char *)realloc(p2,d*sizeof(char));
	printf("enter the sub string:");
	for(i=0;i<d;i++)
	scanf("%c",p2+i);
    for(i=0;i<d;i++)
    {
	if(*(p1+i)==*(p2+i))
	   {
	    count++;
	   }
	}
	if(count==d)
	printf("substring is present");
	else 
	printf("substring is not present");
	free(p1);
	free(p2);
}
