#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p1,*p2;
	int a,b,c,d,i,l1=0,l2=0,flag=0,j,l3=0,l4=0;
	printf("enter size of first string:");
	scanf("%d",&a);
	p1=(char *)malloc(a*sizeof(char));
	printf("enter the string:");
	for(i=0;i<a;i++)
	scanf("%c",p1+i);
	for(i=1;*(p1+i)!='\0';i++)
	l1++;
	printf("enter size of second string:");
	scanf("%d",&b);
	p2=(char *)malloc(b*sizeof(char));
	printf("enter the string:");
	for(i=0;i<b;i++)
	scanf("%c",p2+i);
	for(j=1;*(p2+j)!='\0';j++)
	l2++;
	for(i=0,j=1;*(p1+i)!='\0';i++,j++)
	{
		if(l1!=l2)
		{
			flag=1;
			break;
		}
		else
		{
			if(*(p1+i)!=*(p2+i))
			{
				flag=1;
				break;
			}
		}
	}
	if(flag==1)
	{
	printf("strings are not equal");
}
	else
	{
	printf("strings are equal");
}
	printf("\nenter resize of first string:");
	scanf("%d",&c);
	p1=(char *)realloc(p1,c*sizeof(char));
	printf("enter the string:");
	for(i=0;i<c;i++)
	scanf("%c",p1+i);
	for(i=1;*(p1+i)!='\0';i++)
	l3++;
	printf("enter resize of second string:");
	scanf("%d",&d);
	p2=(char *)realloc(p2,d*sizeof(char));
	printf("enter the string:");
	for(i=0;i<d;i++)
	scanf("%c",p2+i);
	for(j=1;*(p2+j)!='\0';j++)
	l4++;
	for(i=0,j=1;*(p1+i)!='\0';i++,j++)
	{
		if(l3!=l4)
		{
			flag=1;
			break;
		}
		else
		{
			if(*(p1+i)!=*(p2+i))
			{
				flag=1;
				break;
			}
		}
	}
	if(flag==1)
	{
	printf("strings are not equal");
}
	else
	{
	printf("strings are equal");
}
	free(p1);
	free(p2);
}
