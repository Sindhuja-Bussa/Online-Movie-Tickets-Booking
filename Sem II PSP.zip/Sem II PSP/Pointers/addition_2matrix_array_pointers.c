#include<stdio.h>
main()
{
	int a[10][10],*p,b[10][10],*q,c[10][10],*r,i,j,m,n;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	p=a;
	q=b;
	r=c;
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",(p+i*n+j));
	  }	
    } 
	printf("enter order of second matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",(q+i*n+j));
	  }	
   } 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		*(r+i*n+j)=*(p+i*n+j)+*(q+i*n+j);
	  		printf("%3d",*(r+i*n+j));
		}
	  printf("\n");
	}
}
