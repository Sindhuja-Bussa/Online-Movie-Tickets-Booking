#include<stdio.h>
main()
{
    int a,b,c,*p1,*p2,*p3;
    printf("enter the numbers:");
    p1=&a;
    p2=&b;
    p3=&c;
    scanf("%d%d%d",p1,p2,p3);
    if(*p1>*p2 && *p1>*p3)
    {
    	printf("a is greater");
	}
	else if(*p2>*p3)
	{
		printf("b is greater");
	}
	else
	{
		printf("c is greater");
	}
}
