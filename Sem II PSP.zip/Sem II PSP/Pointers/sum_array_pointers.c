#include<stdio.h>
main()
{
	int a[10],n,i,sum=0,*p,*s;
	printf("enter n:");
	scanf("%d",&n);
	p=a;
	s=&sum;
	printf("enter array elements:");
	for(i=0;i<n;i++)
	{
	scanf("%d",(p+i));
    }
	for(i=0;i<n;i++)
	{
	    *s=*s+*(p+i);
	}
	printf("sum of array elements=%d",*s);  
}
