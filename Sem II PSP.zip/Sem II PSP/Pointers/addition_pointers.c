#include<stdio.h>
main()
{
	int a,b,c,*p1,*p2,*p3;
	printf("enter a and b values:");
	p1=&a;
	p2=&b;
	p3=&c;
	scanf("%d %d",p1,p2);
	*p3=*p1+*p2;
	printf("addition=%d",*p3);	
}
