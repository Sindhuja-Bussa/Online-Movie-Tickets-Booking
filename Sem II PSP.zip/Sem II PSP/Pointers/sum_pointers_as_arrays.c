#include<stdio.h>
main()
{
	int a[10],n,i,sum=0,*p[10],*s;
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter array elements:");
	s=&sum;
	for(i=0;i<n;i++)
	{
		p[i]=&a[i];		
	}
	for(i=0;i<n;i++)
	{
	scanf("%d",p[i]);
    }
	for(i=0;i<n;i++)
	{
	    *s=*s+*p[i];
	}
	printf("sum of array elements=%d",*s);  
}
