#include<stdio.h>
main()
{
	int a[10][10],*p;
	int i,j,m,n;
	p=a;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",p+(i*n+j));
	  }	
   }
   printf("\n");
	for(i=0;i<m;i++)
	  {
	  	printf("\n");
	  	for(j=0;j<n;j++)
	  	{
	  	 if(i<=j)
	  	 {
	  	 	printf("%3d",*(p+(i*n+j)));
		 }
		 else
	     {
	    	printf("");
		 }
	  }
  }
 }
