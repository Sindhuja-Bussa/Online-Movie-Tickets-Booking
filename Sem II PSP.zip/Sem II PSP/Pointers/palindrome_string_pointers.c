#include<stdio.h>
main()
{
	char str[10],*p,*q,rev[10];
	int len=0,*len1,i=0,j=0,*j1;
	p=str;
	q=rev;
	j1=&j;
	len1=&len;
	printf("enter the string:");
	gets(str);
	for(;*p!='\0';p++)
	{
		*len1=*len1+1;
    }
   p--;
   for(i=0;i<=*len1-1;i++)
   {
   	*q=*p;
   	q++;
   	p--;
   }
   *(q)='\0';
   p++;
   for(i=0;i<=*len1;i++)
   q--;
   q++;
   while(*p!='\0')
   {
   	if(*p==*q)
   	j++;
   	p++;
   	q++;
   }
   if(*j1==*len1)
   printf("palindrome");
   else
   printf("not a palindome");
}
