#include<stdio.h>
main()
{
	int a,b,c,d,e,*p1,*p2,*p3,*p4,*T;
	float f,*A;
	printf("enter four subject marks:");
	p1=&a;
    p2=&b;
    p3=&c;
    p4=&d;
    T=&e;
    A=&f;  
	scanf("%d%d%d%d",p1,p2,p3,p4);
	*T=*p1+*p2+*p3+*p4;
	*A=(*T)/4;
	if(*A>=91)
	{
		printf("A grade");
	}
	else if(*A>=81)
	{
	    printf("B grade");	
	}
	else if(*A>=71)
	{
	    printf("C grade");	
	}
	else if(*A>=61)
	{
	    printf("D grade");	
	}
	else if(*A>=35)
	{
	    printf("E grade");	
	}
	else 	
	{
		printf("Fail");
	}
}
