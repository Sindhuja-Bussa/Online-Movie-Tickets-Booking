#include<stdio.h>
main()
{
	int a[10][10],b[10][10],c[10][10],*p,*q,i,j,m,n;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	p=a;
	q=b;
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",p+(i*n+j));
		}
	}
	printf("enter order of second matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",q+(i*n+j));
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
		  c[i][j]=*(p+(i*n+j))+*(q+(i*n+j));
		  printf("%3d",c[i][j]);
		 
        }
        printf("\n");
		}
		
		}
