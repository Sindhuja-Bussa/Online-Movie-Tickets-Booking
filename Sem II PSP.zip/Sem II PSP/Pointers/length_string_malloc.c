#include<stdio.h>
#include<stdlib.h>
main()
{
	char *p;
	int n,i,l=0;
	printf("enter size:");
	scanf("%d",&n);
	p=(char*)malloc(n*sizeof(char));
	printf("enter the string:");	
	for(i=0;i<n;i++)
	scanf("%c",p+i);
	for(i=0;i<n;i++)
	{
	  for(;*p!='\0';p++)
		{
     	    l++;
        }
    }
	printf("length of the string=%d",l);
	free(p);
}
