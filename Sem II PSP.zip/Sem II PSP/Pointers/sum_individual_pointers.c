#include<stdio.h>
main()
{
	int n,sum,x,*p;
	printf("enter n value:");
	p=&n;
	scanf("%d",p);
	for(sum=0;*p>0; )
	{
		x=*p%10;
		sum=sum+x;
		*p=*p/10;
	}
	printf("sum=%d",sum);
}
