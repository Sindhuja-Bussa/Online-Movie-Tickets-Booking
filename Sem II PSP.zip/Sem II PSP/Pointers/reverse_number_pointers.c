#include<stdio.h>
main()
{
    int n,rev=0,x,*p;
    printf("enter n value:");
    p=&n;
    scanf("%d",p);
    for(rev=0;*p>0; )
    {
    	x=*p%10;
    	rev=(rev*10)+x;
    	*p=*p/10;
	}
	printf("reversed number=%d",rev);
}
