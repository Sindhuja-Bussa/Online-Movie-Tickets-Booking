#include<stdio.h>
main()
{
    int a,*p1;
    printf("enter the value:");
    p1=&a;
    scanf("%d",p1);
    if(*p1%2==0)
    {
    	printf("even number");
	}
	else 
	{
		printf("odd number");
	}
}
