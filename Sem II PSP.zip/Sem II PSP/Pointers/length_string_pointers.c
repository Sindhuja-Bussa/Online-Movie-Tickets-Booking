#include<stdio.h>
main()
{
	char str[10],*p;
	int l=0;
	printf("enter the string:");
	gets(str);
	for(p=str;*p!='\0';p++)
	{
		l++;
	}
	printf("length of the string=%d",l);
}
