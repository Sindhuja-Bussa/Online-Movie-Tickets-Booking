#include<stdio.h>
main()
{
	int n,fact=1,i,*p;
	printf("enter n value:");
	p=&n;
	scanf("%d",p);
	for(i=1;i<=*p;i++)
	{		
		fact=fact*i;
	}
	printf("factorial=%d",fact);
}
