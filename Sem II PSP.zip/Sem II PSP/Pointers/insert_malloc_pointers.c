#include<stdio.h>
main()
{
	int *p,i,n,pos,k,*element,*position;
	position=&pos;
	element=&k;
	if(p==NULL)
	printf("memory not created");
	printf("\n enter n value:");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("enter elements:");
	for(i=0;i<n;i++)
	{
		scanf("%d",p+i);
    }
	printf("position of an element:");
	scanf("%d",position);
	printf("enter element:");
	scanf("%d",element);
	for(i=n;i>=(*position-1);i--)
		*(p+i+1)=*(p+i);
		*(p+pos-1)=*element;
	for(i=0;i<=n;i++)
	{
		printf("%d\n",*(p+i));
	}
}
