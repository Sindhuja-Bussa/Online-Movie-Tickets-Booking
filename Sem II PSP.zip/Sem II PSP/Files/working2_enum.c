#include<stdio.h>
enum state{working=1,failed=0,freezed=0
};
main()
{
	printf("%3d%3d%3d",working,failed,freezed);
}
