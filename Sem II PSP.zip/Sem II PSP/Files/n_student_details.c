#include<stdio.h>
int i,n;
main()
{
	FILE *fp;
	char name[100];
	char branch[100];
	int age;
	printf("enter no.of student records:");
	scanf("%d",&n);
	fp=fopen("n_student_details.txt","w");
	for(i=0;i<n;i++)
	{
	printf("\t\t\tenter student details\t\t\t\nName\nBranch\nAge\n");
	fscanf(stdin,"%s%s%d",name,branch,&age);
	fprintf(fp,"%s\n%s\n%d",name,branch,age);
    }
	fclose(fp);
	fp=fopen("n_student_details.txt","r");
	printf("Name\tBranch\tAge\n");
	for(i=0;i<n;i++)
	{
	fscanf(fp,"%s%s%d",name,branch,&age);
	fprintf(stdout,"%s\t%s\t%d\n",name,branch,age);
}
	fclose(fp);
}
