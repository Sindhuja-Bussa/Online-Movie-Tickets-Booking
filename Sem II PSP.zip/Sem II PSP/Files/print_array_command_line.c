#include<stdio.h>
main(int argc,char *argv[])
{
	int k,i,a[10];
	int n;
	n=atoi(argv[1]);
	for(k=0;k<n;k++)
	a[k]=atoi(argv[k+2]);
	for(k=0;k<n;k++)
	printf("%3d",a[k]);
}
