#include<stdio.h>
enum week{mon,tue,wed,thur,fri,sat,sun};
main()
{
	enum week day;
	day=wed;
	printf("%d",day);
}
