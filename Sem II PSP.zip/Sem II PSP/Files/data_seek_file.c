#include<stdio.h>
main()
{
	FILE *fp;
	char data[100];
	fp=fopen("C:/Users/sindh/OneDrive/Desktop/Sem II PSP/Files/data_seek.txt","w");
	fputs("Welcome to PSP Programming for CSE and ECE",fp);
	fclose(fp);
	fp=fopen("C:/Users/sindh/OneDrive/Desktop/Sem II PSP/Files/data_seek.txt","r");
	fgets(data,60,fp);
	printf("\n Before SEEK-%s\n",data);
	fseek(fp,21,SEEK_SET);
	fgets(data,60,fp);
	printf("\n After SEEK_SET to 21-%s\n",data);
	fseek(fp,-10,SEEK_CUR);
    fgets(data,45,fp);
	printf("\n After SEEK_CUR to -10-%s\n",data);	
}
