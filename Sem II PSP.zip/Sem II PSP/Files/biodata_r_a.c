#include<stdio.h>
main()
{
	FILE *f1;
	char c;
	f1=fopen("biodataar.txt","a");
	printf("enter data:");
	while((c=getchar())!=EOF)
	putc(c,f1);
	fclose(f1);
	f1=fopen("biodataar.txt","r");
	while((c=getc(f1))!=EOF)
	putchar(c);
	fclose(f1);
}
