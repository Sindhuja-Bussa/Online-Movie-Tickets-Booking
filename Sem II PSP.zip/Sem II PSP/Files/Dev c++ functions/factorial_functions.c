#include<stdio.h>
long long int fact(long long int);
main()
{
	long long int n,z;
	printf("enter n value:");
	scanf("%lld",&n);
	z=fact(n);
	printf("factorial=%lld",z);	
}
long long int fact(long long int n)
{
long long int i,fact=1;
for(i=1;i<=n;i++)
fact=fact*i;
return fact;
}

