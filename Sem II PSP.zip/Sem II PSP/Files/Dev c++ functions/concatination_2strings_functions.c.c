#include<stdio.h>
int cat(char[],char[]);
main()
{
	char str1[100],str2[100];
	int z;
	printf("enter the two strings:");
	gets(str1);
	gets(str2);
	z=cat(str1,str2);
}
int cat(char str1[],char str2[])
{
    int i,l=0;
	for(i=0;str2[i]!='\0';i++)
	l++;
	for(i=0;str1[i]!='\0';i++)
	{
		str2[l]=str1[i];
		l++;
	}
	str2[l]='\0';
	puts(str2);
	return l;
}
