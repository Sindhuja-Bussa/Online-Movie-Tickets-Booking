#include<stdio.h>
main()
{
	char a[20];
	int i;
	printf("enter the string:");
	gets(a);
	for(i=0;i<20;i++)
	printf("\n %c",a[i]);	
}
