#include<stdio.h>
int num(int);
main()
{
	int n,z,m;
	printf("enter n value:");
	scanf("%d",&n);
	z=num(n);
	m=n;
	if(z==m)
	printf("perfect number");
	else
    printf("not a perfect number");       	
}
int num(int n)
{
	int j,i,sum=0;
	for(i=1;i<=n;i++)
	if(n%i==0)
	{
		sum=sum+i;
	}
	j=sum-n;
	return j;
}
