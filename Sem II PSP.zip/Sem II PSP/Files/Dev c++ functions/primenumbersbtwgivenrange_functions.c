#include<stdio.h>
void primerange(int,int);
main()
{
	int x,y,i,count,j;
	printf("enter x value:");
	scanf("%d",&x);
    printf("enter y value:");
    scanf("%d",&y);
	primerange(x,y);
}
void primerange(int x,int y)
{
	int i,count,j;
	for(j=x;j<=y;j++)
	{   
	    if(j==1)
	    printf("1");
		count=0;
		for(i=1;i<=j;i++)
		{
			if(j%i==0)
			count++;
		}
		if(count==2)
		printf("\n%d",j);
	}
}
