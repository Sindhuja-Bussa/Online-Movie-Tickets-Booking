#include"file.c"
int x=10;
main()
{
	printf("\n value of x in main=%d",x);
	display();
	printf("\n value of x after display=%d",x);
}
