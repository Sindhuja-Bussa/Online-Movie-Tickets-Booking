#include<stdio.h>
int strong(int);
main()
{
    int n,m;
    printf("enter n value:");
    scanf("%d",&n);
    m=n;
    if(m==strong(n))
    printf("Strong Number");
    else
    printf("Not a Strong Number");
}
int strong(int n)
{
	int i,fact,x,sum=0;
	while(n>0)
{
	i=1,fact=1;
	x=n%10;
	while(i<=x)
	{
		fact=fact*i;
		i++;
	}
	sum=sum+fact;
	n=n/10;
}
return sum;
}
