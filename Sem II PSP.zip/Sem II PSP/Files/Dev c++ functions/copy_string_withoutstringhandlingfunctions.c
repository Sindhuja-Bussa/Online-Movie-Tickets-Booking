#include<stdio.h>
main()
{
	char str1[100],str2[100];
	int i,l=0,j;
	printf("enter the string:");
	gets(str1);
	for(i=0;str1[i]!='\0';i++)
	l++;
	for(i=0;i<=l;i++)
	{
		str2[j]=str1[i];
		j++;
	}
	puts(str1);
	puts(str2);
}
