#include<stdio.h>
main()
{
	char str[10],rev[10];
	int i,j=0,l=0,count=0;
	printf("enter the string:");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
		l++;
	}
	for(i=(l-1);i>=0;i--)
	{
		rev[j]=str[i];
		j++;
	}
	rev[j]='\0';
	for(i=0;i<l;i++)
	{
		if(str[i]==rev[i])
		count++;
	}
	if(count==l)
	printf("palindrome");
	else
	printf("not a palindrome");
}
