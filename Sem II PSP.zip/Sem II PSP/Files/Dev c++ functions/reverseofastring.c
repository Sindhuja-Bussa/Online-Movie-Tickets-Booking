#include<string.h>
main()
{
	char str1[10],str2[100];
	int z;
	printf("enter the string:");
	gets(str1);
	z=strcpy(str2,str1);
	puts(str1);
	puts(str2);
}
