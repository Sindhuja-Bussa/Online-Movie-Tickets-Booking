#include<string.h>
main()
{
	int n;
	char a[100],b[100];
	printf("enter the first string:");
	gets(a);
	printf("enter the second string:");
	gets(b);
	n=strcat(b,a);
	printf("%s",n);
	
}
