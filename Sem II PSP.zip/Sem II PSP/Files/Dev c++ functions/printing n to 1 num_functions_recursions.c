#include<stdio.h>
int num(int,int);
main()
{
	int x=0,n;
	printf("enter n value:");
	scanf("%d",&n);
    x=1;
	
	num(x,n);	
}
int num(int x,int n)
{
	if(x==n)
	return;
	else
	num(x+1,n);
	printf("%d\n",x);
}
