#include<stdio.h>
int pal(char[]);
main()
{
	char str[100],rev[100];
	int z;
	printf("enter the string:");
	gets(str);
	z=pal(str);
	if(z==1)
	printf("not a palindrome");
	else
	printf("palindrome");
}
int pal(char str[])
{
	int i,l=0;
	for(i=0;str[i]!='\0';i++)
	{
		l++;
	}
	int flag=0,j=0;
	char rev[100];
	for(i=(l-1);i>=0;i--)
	{
		rev[j]=str[i];
		j++;
	}
	rev[j]='\0';
	for(i=0;i<=l;i++)
	{
		if(str[i]!=rev[i])
			flag=1;
			break;
		
	}
	return flag;
	
}

