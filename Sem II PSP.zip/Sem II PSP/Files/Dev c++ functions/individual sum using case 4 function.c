#include<stdio.h>
int sum(int);
main()
{
    int n,z;
    printf("enter n value:");
    scanf("%d",&n);
    z=sum(n);
    printf("individual sum=%d",z);
}
int sum(int n)
{
    int sum,x;
    for(sum=0;n>0; )
    {
        x=n%10;
        sum=sum+x;
        n=n/10;
    }
    return sum;
}