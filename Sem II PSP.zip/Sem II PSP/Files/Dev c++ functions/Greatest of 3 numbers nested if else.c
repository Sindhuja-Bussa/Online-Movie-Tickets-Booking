#include<stdio.h>
main()
{
    int a,b,c;
    printf("\n enter 3 numbers");
    scanf("%d%d%d",&a,&b,&c);
    if(a>b)
    {
        if(a>c)
            printf("a is greater");
        else
            printf("c is greater");
    }
    else
    {
        if(c>b)
            printf("c is greater");
        else
            printf("b is greater");
    }
}