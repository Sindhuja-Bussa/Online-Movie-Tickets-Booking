#include<stdio.h>
int len(char[]);
main()
{
	char str[100];
	int z;
	printf("enter the string:");
	gets(str);
	z=len(str);
	printf("length of the string=%d",z);
}
int len(char str[])
{
	int i,l=0;
	for(i=0;str[i]!='\0';i++)
	{
		l++;
	}
	return l;
}

