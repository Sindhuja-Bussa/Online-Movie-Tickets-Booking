#include<string.h>
main()
{
	int n;
	char a[100],b[100];
	printf("enter two strings:");
	gets(a);
	strcpy(b,a);
	puts(a);
	puts(b);	
}
