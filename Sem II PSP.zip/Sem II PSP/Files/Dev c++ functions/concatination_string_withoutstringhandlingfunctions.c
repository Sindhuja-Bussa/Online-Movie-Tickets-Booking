#include<stdio.h>
main()
{
	char str1[100],str2[100];
	int i,l=0;
	printf("enter the two strings:");
	gets(str1);
	gets(str2);
	for(i=0;str2[i]!='\0';i++)
	l++;
	for(i=0;str1[i]!='\0';i++)
	{
		str2[l]=str1[i];
		l++;
	}
	str2[l]='\0';
	puts(str2);
}
