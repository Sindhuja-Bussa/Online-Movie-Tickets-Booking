extern int x;
void display()
{
	printf("\n value of x in display=%d",x);
	x=x+10;
}
