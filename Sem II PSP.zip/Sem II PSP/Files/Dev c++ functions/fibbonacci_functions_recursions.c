#include<stdio.h>
int fib(int);
main()
{
	int n,i,z;
	printf("enter n value:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	z=fib(i);
	printf("%3d",z);
    }   
}
int fib(int x)
{
	if((x==0)||(x==1))
	return x;
	else
	return(fib(x-1)+fib(x-2));
}
