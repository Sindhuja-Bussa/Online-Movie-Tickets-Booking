#include<string.h>
main()
{
	int n;
	char a[100],b[100];
	printf("enter the string:");
	gets(a);
	strcpy(b,a);
	strrev(a);
	n=strcmp(b,a);
	if(n==0)
	printf("palindrome");
	else
	printf("not a palindrome");
	
}
