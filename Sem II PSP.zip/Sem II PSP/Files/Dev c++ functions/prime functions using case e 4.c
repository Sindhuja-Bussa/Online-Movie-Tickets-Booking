#include<stdio.h>
int prime(int);
main()
{
	int n,z;
	printf("Enter a number\n");
	scanf("%d",&n);
	z=prime(n);
	if(z==2)
	printf("prime number");
	else
	printf("not a prime number");
}
int prime(int n)
{
	int count=0,i=1;
	while(i<=n)
	{
		if(n%i==0)
		count++;
		i++;
	}
	return count;
}