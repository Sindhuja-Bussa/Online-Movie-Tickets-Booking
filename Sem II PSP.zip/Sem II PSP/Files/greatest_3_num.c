#include<stdio.h>
main(int argc,char *argv[])
{
	int a,b,c;
	a=atoi(argv[1]);
	b=atoi(argv[2]);
	c=atoi(argv[3]);
	if(a>b && a>c)
	{
		printf("a is greater");
	}
	else if(b>a && a>c)
	{
		printf("b is greater");
	}
	else
	{
		printf("c is greater");
	}
}
