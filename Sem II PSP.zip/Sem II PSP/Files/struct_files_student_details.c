#include<stdio.h>
struct student
{
	char name[100];
	char branch[100];
	int age;
}s;
int i,a,x,flag=0,flag1=0;
char n[100];
FILE *fs,*fp;
void read();
void display(struct student);
void add();
void search1();
void search2();
main()
{
	int ch,ch1;
	do
	{
		printf("\n1.To Display Student Details\n2.To Add the Record\n3.To Search the Record with roll no\n4.To Search the Record with rollno and name\n ");
	    printf("enter your choice:\n");
		scanf("%d",&ch);
		switch(ch)
		{
		   case 1:
		   	    display(s);
		   	    break;
		   case 2:
		   	    add();
		   	    break;
		   case 3:
		   	    search1();
		   	    break;
		  case 4:
		  	    search2();
		   	    break;
		   	    
		}
		printf("\npress 1 to continue:");
		scanf("%d",&ch1);
		
	}while(ch1==1);
	
}
void display(struct student s)
{
	fs=fopen("struct_n_student_details.txt","w");
	fp=fopen("struct_student_details.txt","r");
	printf("\nName\tBranch\tAge\n"); 
	while(fscanf(fp,"%s%s%d",s.name,s.branch,&s.age)!=EOF)
	{
	fprintf(fs,"%s\n%s\n%d\n",s.name,s.branch,s.age);
    fprintf(stdout,"\n%s\t%s\t%d\n",s.name,s.branch,s.age);
    }
	fclose(fp);
    fclose(fs);
}
void add()
{
   fs=fopen("struct_n_student_details.txt","a");
   fscanf(stdin,"%s%s%d",s.name,s.branch,&s.age);
   fprintf(fs,"%s\t%s\t%d\t",s.name,s.branch,s.age);
   fclose(fs);
}
void search1()
{
	printf("enter the age to be search:");
	scanf("%d",&a);
	fs=fopen("struct_n_student_details.txt","r");
	while(fscanf(fs,"%s%s%d",s.name,s.branch,&s.age)!=EOF)
	{
	if(a==s.age)
	{
		flag=10;
		break;
	}
    }
    if(flag==10)
    {
		fprintf(stdout,"\n%s\t%s\t%d\n",s.name,s.branch,s.age);
		fclose(fs);
		printf("record found\n");
	}
	else
	{
		printf("record not found");
	}
}
  
void search2()
{
	printf("enter the age to be search:");
	scanf("%d",&a);
	printf("enter the name to be search:");
	scanf("%s",n);
	fs=fopen("struct_n_student_details.txt","r");
	while(fscanf(fs,"%s%s%d",s.name,s.branch,&s.age)!=EOF)
	{
	x=strcmp(n,s.name);
	if(x==0&&a==s.age)
	{
		flag1=11;
		break;
    }
    }
   if(flag1==11)
    {
		fprintf(stdout,"\n%s\t%s\t%d\n",s.name,s.branch,s.age);
		fclose(fs);
		printf("\n record found");
	}
	else
	{
		printf("record not found");	
	}
}
