#include<stdio.h>
enum week{sunday=1,monday,tuesday=5,wednesday,thursday=10,friday,saturday};
main()
{
	printf("%3d%3d%3d%3d%3d%3d%3d",sunday,monday,tuesday,wednesday,thursday,friday,saturday);
}
