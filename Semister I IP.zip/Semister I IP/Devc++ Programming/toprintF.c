/* to print F using hash has a height of seven and width of six and five */
#include<stdio.h>
main()
{
	printf("######");
	printf("\n#");
	printf("\n#");
	printf("\n#####");
	printf("\n#");
	printf("\n#");
	printf("\n#");
}
