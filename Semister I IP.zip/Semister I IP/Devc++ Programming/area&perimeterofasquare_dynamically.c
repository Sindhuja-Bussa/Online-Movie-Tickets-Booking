#include<stdio.h>
main()
{
	int s;
	int area;
	int perimeter;
	printf("enter s: ");
	scanf("%d",&s);
	area=s*s;
	perimeter=4*s;
	printf("area=%d",area);
	printf("\nperimeter=%d",perimeter);
}
