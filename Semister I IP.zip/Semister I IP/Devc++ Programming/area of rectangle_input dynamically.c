#include<stdio.h>
main()
{
	int length;
	int breadth;
	int area;
	printf("enter length:");
	scanf("%d",&length);
	printf("enter breadth:");
	scanf("%d",&breadth);
	area=length*breadth;
	printf("the result=%d",area);
}
