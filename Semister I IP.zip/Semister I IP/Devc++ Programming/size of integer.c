main()
{
	int a=32768;
	printf("int size=%d",sizeof(int));
	printf("\nint size=%d",sizeof(long long int));
	printf("\nresult=%d",a);
}
