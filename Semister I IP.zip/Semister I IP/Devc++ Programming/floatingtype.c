main()
{
    double a=41.6835;
	 
	printf("the result=%lf",a);
}
