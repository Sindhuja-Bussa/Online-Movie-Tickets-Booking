#include<math.h>
main()
{
	printf("sqrt(9)");
}
