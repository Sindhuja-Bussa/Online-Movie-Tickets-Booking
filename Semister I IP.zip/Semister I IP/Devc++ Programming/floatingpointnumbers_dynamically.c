#include<stdio.h>
main()
{
	float a;
	float b;
	float c;
	printf("enter a");
	scanf("%f",&a);
	printf("enter b");
	scanf("%f",&b);
	c=a+b;
	printf("the result=%f",c);
}
