#include<math.h>
main()
{
	printf("%f",pow(4,3));
}
