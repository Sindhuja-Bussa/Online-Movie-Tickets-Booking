/* this is a program to print multiple lines */
#include<stdio.h>
main()
{
	printf("firstname:sindhuja");
	printf("\nlastname:bussa");
	printf("\nDOB:24-10-2003");
	printf("\nsection:B1");
}
