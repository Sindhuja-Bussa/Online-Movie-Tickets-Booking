#include<stdio.h>
main()
{
	int r=5;
	float volume;
	volume=3.14*1.3*r*r*r;
	printf("the volume=%f",volume);
}
