#include<stdio.h>
main()
{
	int Tc;
	float Tf;
	printf("enter temp in celsius:");
	scanf("%d",&Tc);
	Tf=Tc*1.8+32;
	printf("temp in fahrenhit=%f",Tf);
}
