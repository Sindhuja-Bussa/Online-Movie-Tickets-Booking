#include<stdio.h>
main()
{
	int a,b,c,d,e;
	printf("enter a:");
	scanf("%d",&a);
	printf("enter b:");
	scanf("%d",&b);
	c=a&b;
	d=a|b;
	e=a^b;
	printf("bitwise AND=%d,\nbitwise OR=%d,\nbitwise Exclusive OR=%d",c,d,e);	
}
