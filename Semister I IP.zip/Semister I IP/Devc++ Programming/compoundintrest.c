#include<math.h>
main()
{
	int p=1000;
	int r=2;
	int n=2;
	int t=3;
	float A;
	A=p*(pow((1+r/n),(n*t)));
	printf("the result=%f",A);
}
