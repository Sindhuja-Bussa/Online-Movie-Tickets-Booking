#include<stdio.h>
main()
{
	int r;
	int h;
	float volume;
	printf("enter radius:");
	scanf("%d",&r);
	printf("enter height:");
	scanf("%d",&h);
	volume=(3.14*1.3*r*r*r);
	printf("the volume=%f",volume);
}
