#include<stdio.h>
main()
{
	int x1,x2,y1,y2;
	float d;
	printf("enter the value of x1:");
	scanf("%d",&x1);
	printf("enter the value of x2:");
	scanf("%d",&x2);
	printf("enter the value of y1:");
	scanf("%d",&y1);
	printf("enter the value of y2:");
	scanf("%d",&y2);
	d=sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));
    printf("the distance=%f",d);
}
