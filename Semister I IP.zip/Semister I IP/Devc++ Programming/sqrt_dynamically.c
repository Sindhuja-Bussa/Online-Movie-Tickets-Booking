#include<stdio.h>
#include<math.h>
main()
{
	int x;
	int y;
	printf("enter the value of x:");
	scanf("%d",&x);
	y=sqrt(x);
	printf("square root of a number=%d",y);
}
