#include<stdio.h>
main()
{
	int m1;
	int m2;
	int m3;
	int m4;
	int m5;
	int total;
	float average;
	printf("enter the value of m1:");
	scanf("%d",&m1);
	printf("enter the value of m2:");
	scanf("%d",&m2);
	printf("enter the value of m3:");
	scanf("%d",&m3);
	printf("enter the value of m4:");
	scanf("%d",&m4);
	printf("enter the value of m5:");
	scanf("%d",&m5);
    total=(m1+m2+m3+m4+m5);
    average=((m1+m2+m3+m4+m5)/5);
    printf("the total=%d,\nthe average=%f",total,average);
}
