#include<stdio.h>
main()
{
	int p;
	int t;
	int r;
	float si;
	printf("enter principal amount:");
	scanf("%d",&p);
	printf("enter time:");
	scanf("%d",&t);
	printf("enter rate of intrest:");
	scanf("%d",&r);
	si=(p*t*r)/100;
	printf("the result=%f",si);
}
