#include<stdio.h>
#include<math.h>
main()
{
	printf("e=%f",5-3+(4/6)*7-pow(3,3)*4-(7/6)*2-pow(3,3)/2+6-7+2);
}
