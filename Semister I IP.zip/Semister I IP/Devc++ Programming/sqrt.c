#include<stdio.h>
#include<math.h>
main()
{
	float x=4;
	printf("%f",sqrt(x));
}
