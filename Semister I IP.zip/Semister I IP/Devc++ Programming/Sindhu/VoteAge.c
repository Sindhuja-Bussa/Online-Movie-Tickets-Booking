#include<stdio.h>
main()
{
	int age;
	printf("enter age: ");
	scanf("%d",&age);
	if(age>=18)
	{
		printf("eligible to vote");
	}
	if(age<18)
	{
		printf("\nnot eligible to vote");
	}
	printf("\nhello");
}

