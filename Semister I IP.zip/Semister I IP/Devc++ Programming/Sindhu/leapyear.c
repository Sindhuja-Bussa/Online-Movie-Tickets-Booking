#include <stdio.h>
main() {
   int year;
   printf("Enter a year: ");
   scanf("%d", &year);

   if (year % 4 == 0) 
   {
      printf("it is a leap year");
   }
   
   if (year %4 != 0) 
   {
      printf("it is not a leap year");
   }
   
}
