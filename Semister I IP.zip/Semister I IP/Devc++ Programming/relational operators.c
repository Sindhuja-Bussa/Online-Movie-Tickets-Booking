#include<stdio.h>
main()
{
	int a;
	int b;
	printf("enter a:");
	scanf("%d",&a);
	printf("enter b:");
	scanf("%d",&b);
	printf("result=%d",a>b);
}
