#include<stdio.h>
#include<conio.h>
main()
{
	printf("welcome to sru");
}
