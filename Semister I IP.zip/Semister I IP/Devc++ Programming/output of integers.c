#include<stdio.h>
main()
{
	int i=3214;
	printf("i=%d",i);
	printf("\ni=%3d",i);
	printf("\ni=%-7d",i);
	printf("\ni=%10d",i);	
}
