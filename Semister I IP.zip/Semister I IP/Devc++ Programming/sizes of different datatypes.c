#include<stdio.h>
main()
{
	int x=6;
	float y=4.5;
	printf("size=%d",sizeof(int));
    printf("\nsize=%d",sizeof(x));
	printf("\nsize=%d",sizeof(6));
	printf("\nsize=%d",sizeof(float));	
	printf("\nsize=%d",sizeof(y));
	printf("\nsize=%d",sizeof(4.5));
	printf("\nsize=%d",sizeof(char));
}
