#include<stdio.h>
main()
{
	int a=10;
	int b=20;
	int sum;
	sum=a+b;
	printf("the result=%d",sum);
}
