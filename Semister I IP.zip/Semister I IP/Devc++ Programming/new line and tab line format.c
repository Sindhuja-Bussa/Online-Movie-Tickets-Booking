#include<stdio.h>
#include<conio.h>
main()
{
	printf("\twelcome to sru");
	printf("\nb1 section");
}
