#include<stdio.h>
main()
{
	int a=20;
	int b=50;
	printf("the result=%d",a>0&&b<100);
    printf("\nthe result=%d",a<0&&b>100);
	printf("\nthe result=%d",a>0||b<100);
	printf("\nthe result=%d",a<0||b<100);	
}
