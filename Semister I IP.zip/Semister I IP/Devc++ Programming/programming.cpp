#include<stdio.h>
#include<conio.h>
main()
{
	printf("welcome to sru");
	printf("\nhappy to see you");
	printf("\nwanna fly");
}
