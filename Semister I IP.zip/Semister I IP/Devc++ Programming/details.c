/* to print multiple lines */
#include<stdio.h>
main()
{
	printf("firstname:sindhuja");
	printf("\n----------------");
	printf("\nlastname:bussa");
	printf("\n-----------------");
	printf("\nDOB:24-10-2003");
	printf("\n----------------");
	printf("\nsection:B1");
	printf("\n----------------");
	printf("\ndepartment:CSE");
}
