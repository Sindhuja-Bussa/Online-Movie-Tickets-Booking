#include<stdio.h>
main()
{
	float a=32.0142;
	printf("a=%3.2f",a);
	printf("\na=%5.1f",a);
	printf("\na=%6.3f",a);
}
