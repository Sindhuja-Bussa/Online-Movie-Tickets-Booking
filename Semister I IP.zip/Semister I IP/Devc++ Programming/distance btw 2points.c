#include<stdio.h>
#include<math.h>
main()
{
	float x1=6;
	float x2=8;
	float y1=5;
	float y2=8;
	float d;
	d=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
    printf("the distance=%f",d);
}
