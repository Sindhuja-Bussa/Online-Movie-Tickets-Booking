#include<stdio.h>
main()
{
	int b;
	int h;
	float area;
	printf("enter base:");
	scanf("%d",&b);
	printf("enter height:");
	scanf("%d",&h);
	area=0.5*b*h;
	printf("the area=%f",area);
}
