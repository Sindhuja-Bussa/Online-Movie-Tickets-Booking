#include<stdio.h>
main()
{
	int a[10][10],b[10][10],c[10][10];
	int i,j,m,n;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",&a[i][j]);
	  }	
   } 
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",&b[i][j]);
	  }	
   } 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		c[i][j]=a[i][j]+b[i][j];
	  		printf("%3d",c[i][j]);
		}
	  printf("\n");
	}
}
