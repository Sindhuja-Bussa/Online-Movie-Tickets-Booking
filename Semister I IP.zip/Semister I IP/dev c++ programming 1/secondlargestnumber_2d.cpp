#include<stdio.h>
main()
{
	int a[10][10];
	int i,j,m,n,large1,large2;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",&a[i][j]);
	  }	
    }
	large1=0; 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  	 if(a[i][j]>large1)
	  	 large1=a[i][j];
		}
	 }
	 large2=0; 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  	 if(a[i][j]>large2 && a[i][j]<large1)
	  	 large2=a[i][j];
		}
	 }
   printf(" second largest number=%d",large2);
}
