#include<stdio.h>
main()
{
	int type,item,np,a;
	printf("1.tiffin\n2.snacks\n3.meals\n\n");
	printf("1.idly\n2.dosa\n3.wada\n\n");
	printf("1.veg\n2.non veg\n\n");
	printf("1.pizza\n2.burger\n\n");
	printf("type of item\nfood\nno.of plates");
	scanf("%d%d%d",&type,&item,&np);
	switch(type)
	{
		case 1:switch(item)
		{
			case1:a=np*10;
			printf("amount=%d",a);
			break;
			case2:a=np*5;
			printf("amount=%d",a);
			break;
			case3:a=np*20;
			printf("amount=%d",a);
			break;
	    }
	    break;
	    case 2:switch(item)
	    {
	    	case1:a=np*100;
	    	printf("amount=%d",a);
	    	break;
	    	case2:a=np*250;
	    	printf("amount=%d",a);
	    	break;
		}
		break;
		case 3:switch(item)
		{
			case1:a=np*50;
			printf("amount=%d",a);
			break;
			case2:a=np*100;
			printf("amount=%d",a);
			break;
		}
		break;
		}	
	}
