#include<stdio.h>
main()
{
	int x;
	printf("enter x value:");
	scanf("%d",&x);
	if(x%2==0)
  {
      if(x>0)
	 {
	   printf("positive even number");
     }
    else	
     {
       printf("negative even number");
     }
  }
 else
	 {
    if(x>0)
	 {
	   printf("positive odd number");
     }
    else	
     {
       printf("negative odd number");
     }
  }
}
