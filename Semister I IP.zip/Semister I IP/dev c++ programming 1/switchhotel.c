#include<stdio.h>
main()
{
  int tf,ti,np,r;
  printf("1.Tiffins\n2.Meals\n3.Snacks\n\n");
  printf("1.Idly\n2.Dosa\n3.Wada\n\n");
  printf("1.Veg\n2.Non veg\n\n");
  printf("1.Pizza\n2.Burger\n\n");
  printf("Type of food:");
  scanf("%d",&tf);
  printf("Type of item:");
  scanf("%d",&ti);
  printf("No.of Plates:");
  scanf("%d",&np);
  switch(tf)
  {
  	case 1:switch(ti)
	  {
  		case 1:r=np*10;
  		printf("rate=%d",r);
		break;
	    case 2:r=np*5;
  		printf("rate=%d",r);
  		break;
    	case 3:r=np*20;
  		printf("rate=%d",r);
		break;
	  }
	  break;
	case 2:switch(ti)
	  {
  		case 1:r=np*100;
  		printf("rate=%d",r);
		break;
	    case 2:r=np*250;
  		printf("rate=%d",r);
  		break;
    }
    break;
   case 3:switch(ti)
   {
   	  case 1:r=np*50;
      printf("rate=%d",r);
	  break;
	  case 2:r=np*100;
  	  printf("rate=%d",r);
  	  break;
    }
    break;
}	
}
