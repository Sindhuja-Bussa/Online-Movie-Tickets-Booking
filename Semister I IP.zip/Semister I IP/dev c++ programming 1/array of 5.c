#include<stdio.h>
main()
{
	int i;
	int a[5];
	printf("enter array value:");
	for(i=0;i<5;i++)
	scanf("%d",&a[i]);
	for(i=0;i<5;i++)
	{
		printf("%d\n",a[i]);
	}
}
