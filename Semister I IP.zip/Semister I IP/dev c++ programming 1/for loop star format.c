#include<stdio.h>
main()
{
	int i,k,j,n;
	printf("enter n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		for(k=0;k<=n-i;k++)
		{
		printf(" ");
	    }
		for(j=5;j>=i;j--)
		{
		printf("*");
		printf(" ");
	   }
	   printf("\n");
    }
}
