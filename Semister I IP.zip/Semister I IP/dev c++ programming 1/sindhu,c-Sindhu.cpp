#include<stdio.h>
main()
{
	int a[10][10],b[10][10],i,j,m,n,p,q,k,l,c[10][10];
	printf("enter order of matrix:");
	scanf("%d %d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
		scanf("%d",&a[i][j]);
	 }
    }
   for(i=0;i<m;i++)
	{		
   for(j=0;j<n;j++)
   {
	printf("%3d",a[i][j]);
   }
   printf("\n");
  }
  printf("enter order of second matrix:");
	scanf("%d %d",&p,&q);
	printf("enter elements:");
   for(k=0;k<p;k++) 
	{		
   for(l=0;l<q;l++)
   {
	printf("%3d",b[k][l]);
   }
   printf("\n");
  }
 if(n==p)
 {
 	for(i=0;i<m;i++)
	{
	for(j=0;j<n;j++)
	 {
	 	c[i][j]=0;
	 	for(k=0;k<n;k++)
	 	{
	 		c[i][j]=c[i][j]+(a[i][k]*b[k][j]);
		 }
     }
     printf("resultant matrix");
     printf("\n");
     for(i=0;i<m;i++)
     {
     	for(j=0;j<q;j++)
     	 {
     		printf("%4d",c[i][j]);
		}
		 printf("\n");
	 }
 	
 }
}
else
{
	printf("enter correct order");
}
}
