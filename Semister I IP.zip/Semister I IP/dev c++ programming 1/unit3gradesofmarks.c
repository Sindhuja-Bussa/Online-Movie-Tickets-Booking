#include<stdio.h>
main()
{
	int m1,m2,m3,m4,total;
	float A;
	printf("enter m1:");
	scanf("%d",&m1);
	printf("enter m2:");
	scanf("%d",&m2);
	printf("enter m3:");
	scanf("%d",&m3);
	printf("enter m4:");
	scanf("%d",&m4);
	total=(m1+m2+m3+m4);
	A=(total*100)/400;
	if(A>=91)
	{
		printf("A grade");
	}
	else if(A>=81&&A<91)
	{
	    printf("B grade");	
	}
	else if(A>=71&&A<81)
	{
	    printf("C grade");	
	}
	else if(A>=61&&A<71)
	{
	    printf("D grade");	
	}
	else 
	{
	    printf("E grade");
	}
}
