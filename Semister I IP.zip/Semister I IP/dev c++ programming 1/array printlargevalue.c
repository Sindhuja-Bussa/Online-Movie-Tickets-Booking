#include<stdio.h>
main()
{
	int i,large=0,n,a[10];
	printf("enter n:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
	    if(a[i]>large)
		large=a[i];
	}
	printf("largest number=%d",large);
}
