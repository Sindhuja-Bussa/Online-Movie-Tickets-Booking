#include<stdio.h>
main()
{
	int a[100],a1[100],a2[100],i,n,x=0,y=0;
	printf("enter n:");
	scanf("%d",&n);
	printf("enter array values:");
	int j,k;
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]%2==0)
	    {
          a1[j]=a[i];
          j++;
		  x++;	
	    }
	 else
	   {
		a2[k]=a[i];
		k++;
		y++;
	   }	
   }
   printf("even numbers:");
   for(j=0;j<x;j++)
   printf("%3d",a1[j]);
   printf("\n");
   printf("odd numbers:");
   for(k=0;k<y;k++)
   printf("%3d",a2[k]);
}
