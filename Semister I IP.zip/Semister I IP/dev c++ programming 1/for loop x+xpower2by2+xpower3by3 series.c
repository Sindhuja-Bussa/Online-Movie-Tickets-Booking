#include<stdio.h>
main()
{
	int x,i,n;
	float sum=0,y;
	printf("enter x value:");
	scanf("%d",&x);
	printf("enter n value:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		y=(pow(x,i))/i;
		sum=sum+y;
	}
	printf("sum=%f",sum);
	
}
