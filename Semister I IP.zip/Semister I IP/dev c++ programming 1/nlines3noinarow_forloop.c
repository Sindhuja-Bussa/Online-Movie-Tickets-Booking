#include<stdio.h>
main()
{
	int i=1,n,count=1,k;
	printf("enter n:");
	scanf("%d",&n);
	for( ;i<=n;i++)
	{
		for(k=1;k<=3;k++)
		{
			printf("%3d",count);
			count++;
		}
		printf("\n");
	}
}
