#include<stdio.h>
main()
{
	int g,a,b;
	float result;
	printf("Enter 1 to calculate area of rectangle");
	printf("\nEnter 2 to calculate area of square");
	printf("\nEnter 3 to calculate area of circle");
	printf("\nEnter 4 to calculate area of traingle");
	printf("\nEnter geometrical shape:");
	scanf("%d",&g);
	switch(g)
	{
		case 1:
		{
			printf("Enter length and breadth:");
			scanf("%d%d",&a,&b);
			result=a*b;
			printf("area of rectangle=%f",result);
			break;
		}
		case 2:
		{
		    printf("Enter side:");
			scanf("%d",&a);
			result=a*a;
			printf("area of square=%f",result);
			break; 	
		}
		case 3:
		{
			printf("Enter radius:");
			scanf("%d",&a);
			result=3.14*a*a;
			printf("area of circle=%f",result);
			break;
		}
		case 4:
		{
	        printf("Enter base and height:");
			scanf("%d%d",&a,&b);
			result=0.5*a*b;
			printf("area of triangle=%f",result);
			break;	
		}	
	}
	
}
