#include<stdio.h>
main()
{
	char ch;
	printf("enter charecter:");
	scanf("%c",&ch);
	switch(ch)
	{
		case 'o':printf("orange");
		         break;
		case 'p':printf("purple");
		         break;        
	    case 'r':printf("red");
		         break;
		case 'y':printf("yellow");
		         break;	
		case 'g':printf("green");
				 break;	         
	}
}
