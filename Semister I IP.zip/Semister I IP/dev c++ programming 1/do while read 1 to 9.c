#include<stdio.h>
main()
{
	char ch;
	char ch1;
	do
	{
	printf("enter character:");
	scanf("%c",&ch);
	switch(ch)
	{
		case 0:printf("zero");
		   break;
		case 1:printf("one");
		   break;
		case 2:printf("two");
		   break;
		case 3:printf("three");
		   break;
		case 4:printf("four");
		   break;
		case 5:printf("five");
		   break;
		case 6:printf("six");
		   break;
		case 7:printf("seven");
		   break;
		case 8:printf("eight");
		   break;
		case 9:printf("nine");
		   break;		   	
	}
	printf("\n press y to continue");
	scanf("%c",&ch1);
    }while(ch1=='y');
}
