#include<stdio.h>
main()
{
	int x;
	printf("enter x value:");
	scanf("%d",&x);
	if(x>0)
	{
		printf("1");
	}
	else if(x==0)
	{
		printf("0");
	}
	else
	{
	    printf("-1");	
	}
	
}
