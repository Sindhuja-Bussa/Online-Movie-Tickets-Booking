#include<stdio.h>
#include<math.h>
main()
{
	int a,b;
	float c;
	char ch;
	printf("\n +:addition");
	printf("\n -:subtraction");
	printf("\n *:multiplication");
	printf("\n /:division");
	printf("\n %:modulo division");
    printf("\n sqrt:square root");
    printf("\n pow:power");
	printf("\n enter character");
	scanf("%c",&ch);
	printf("enter the values");
	scanf("%d%d",&a,&b);
	switch(ch)
	{
		case '+':printf("\n result=%f",c=a+b);
		         break;
		case '-':printf("\n result=%f",c=a-b);
		         break;
		case '*':printf("\n result=%f",c=a*b);  
		         break;
		case '/':printf("\n result=%f",c=a/b);     
		         break;
		case '%':printf("\n result=%f",c=a%b);
		         break;
		case 'sqrt':printf("\n result=%f",c=sqrt(a+b-b));
                    break;        
		case 'pow':printf("\n result=%f",c=pow(a,b));
                   break;			         						 			         
	}
}
