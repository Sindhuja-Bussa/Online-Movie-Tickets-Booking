#include<stdio.h>
main()
{
	int a[10][10];
	int i,j,m,n,large=0,large2=0;
	printf("enter order of matrix:");
	scanf("%d%d",&m,&n);
	printf("enter elements:");
	for(i=0;i<m;i++)
	{
	  for(j=0;j<n;j++)
	  {
	  	scanf("%d",&a[i][j]);
	  }	
   } 
	for(i=0;i<m;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  	 large=a[0][0];
	  	 if(a[i][j]>large2 && a[i][j]<large)
	  	 large2=a[i][j];
		}
	 }
   printf("second largest number=%d",large2);
}
