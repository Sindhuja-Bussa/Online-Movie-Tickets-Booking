#include<stdio.h>
main()
{
	int i,k,j,n;
	printf("enter n:");
	scanf("%d",&n);
	for(i=n;i>0;i--)
	{
		for(k=1;k<=n-i;k++)
		{
		printf(" ");
	    }
		for(j=5;j>=i;j--)
		{
		printf("*");
		printf(" ");
	   }
	   printf("\n");
    }
}
