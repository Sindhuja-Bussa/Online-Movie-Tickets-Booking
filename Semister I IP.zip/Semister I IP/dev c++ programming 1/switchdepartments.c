#include<stdio.h>
main()
{
	int d,n,s;
	printf("Enter 1 for CSE");
	printf("\nEnter 2 for ECE");
	printf("\nEnter 3 for EEE");
	printf("\nEnter 4 for Civil");
	printf("\nEnter your department:");
	scanf("%d",&d);
	printf("Enter No.of Employees:");
	scanf("%d",&n);
	switch(d)
	{
		case 1:s=n*50000;
		       printf("salary=%d",s);   
		       break;
	    case 2:s=n*40000;
		       printf("salary=%d",s);
		       break; 
		case 3:s=n*35000;
		       printf("salary=%d",s);
		       break;
		case 4:s=n*38000;
		       printf("salary=%d",s);
		       break;       			
	}	
}
