#include<stdio.h>
main()
{
	char ch,d,c;
	printf("enter any charecter:");
	scanf("%c",&ch);
	c=ch-32;
	d=ch+32;
	if((ch>='a'&&ch<='z'))
	{
		printf("result=%c",c);
	}
	else 
	{
		printf("result=%c",d);
	}
}
