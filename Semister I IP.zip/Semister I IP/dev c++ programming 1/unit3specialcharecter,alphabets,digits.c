#include<stdio.h> 
main()
{ 
   char ch;  
   printf("Enter any character: "); 
   scanf("%c", &ch);  
   if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
   {
        printf("alphabet"); 
   } 
   else if(ch >= '0' && ch <= '9') 
   { 
        printf("digits"); 
   } 
   else 
   { 
        printf("special charecter"); 
   }
}
