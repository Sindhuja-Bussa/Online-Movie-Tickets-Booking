#include<stdio.h>
main()
{
	char ch;
	printf("enter character:");
	scanf("%c",&ch);
	switch(ch)
	{
		case 'a':printf("\nvowel");
		         break; 
		case 'e':printf("\nvowel");
		         break; 
		case 'i':printf("\nvowel");
		         break;
		case 'o':printf("\nvowel");
		         break;
		case 'u':printf("\nvowel");
		         break;  
		default:printf("\nconsonant");		 		   		   		  		         
	}
}
