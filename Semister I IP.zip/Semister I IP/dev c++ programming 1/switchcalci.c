#include<stdio.h>
#include<math.h>
main()
{
	int a,b;
	float result;
	char ch;
	printf("\n 1 for addition");
	printf("\n 2 for subtraction");
	printf("\n 3 for multiplication");
	printf("\n 4 for division");
	printf("\n 5 for Modulo division");
	printf("\n 6 for power");
	printf("\n 7 for square rooot");
	printf("\n enter character:");
	scanf("%c",&ch);
	printf("\nenter 2 numbers:");
	scanf("%d%d",&a,&b);
	switch(ch)
	{
		case 1:result=a+b;
		       printf("\n result=%f",result);
		       break;
		case 2:result=a-b;
		       printf("\n result=%f",result);
		       break;
		case 3:result=a*b;
		       printf("\n result=%f",result);
		       break;
	    case 4:result=a/b;
		       printf("\n result=%f",result);
		       break;
		case 5:result=a%b;
		       printf("\n result=%f",result);
		       break;   
		case 6:result=pow(a,b);
		       printf("\n result=%f",result);
		       break;
		case 7:result=sqrt(a+b-b);
		       printf("\n result=%f",result);
		       break;       
    }
}

