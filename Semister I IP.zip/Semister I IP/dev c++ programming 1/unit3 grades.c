#include<stdio.h>
main()
{
	int m;
	printf("enter marks:");
	scanf("%d",&m);
	if(m>=91)
	{
		printf("A grade");
	}
	else if(m>=81)
	{
	    printf("B grade");	
	}
	else if(m>=71)
	{
	    printf("C grade");	
	}
	else if(m>=61)
	{
	    printf("D grade");	
	}
	else if(m>=35)
	{
	    printf("E grade");	
	}
	else 	
	{
		printf("fail");
	}
}
