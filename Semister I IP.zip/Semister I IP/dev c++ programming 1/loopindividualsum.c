#include<stdio.h>
main()
{
	int n,sum=0,i;
	printf("enter n value:");
	scanf("%d",&n);
	while(n>0)
	{
		i=n%10;
		sum=sum+i;
		n=n/10;
	}
	printf("sum=%d",sum);
}
