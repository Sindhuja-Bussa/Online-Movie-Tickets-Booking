#include<stdio.h>
main()
{
	int esum=0,osum=0,n,i;
	printf("enter n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		if(i%2==0)
		{
			esum=esum+i;
		}
		else
		{
			osum=osum+i;
		}
	}
	printf("esum=%d,\nosum=%d",esum,osum);	
}
