#include<stdio.h>
main()
{
	char ch;
	int a,A,z,Z;
	printf("enter alphabet:");
	scanf("%c",&ch);
	if(ch>=a&&ch<=z)
	{
		int a=ch-32;
		printf("lower case");
	}
	if(ch>=A&&ch<=Z)
	{
		int A=ch+32;
		printf("upper case");		
	}
}
