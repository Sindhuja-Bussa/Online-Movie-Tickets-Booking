#include<stdio.h>
main()
{
	int a,b,result;
	char ch;
	printf("\n 1 for addition");
	printf("\n 2 for subtraction");
	printf("\n 3 for multiplication");
	printf("\n 4 for division");
	printf("\n 5 for modulo division");
	printf("\n enter character:");
	scanf("%c",&ch);
	printf("\nenter 2 numbers:");
	scanf("%d%d",&a,&b);
	switch(ch)
	{
		case 1:result=a+b;
		       printf("\n result=%d",result);
		       break;
		case 2:result=a-b;
		       printf("\n result=%d",result);
		       break;
		case 3:result=a*b;
		       printf("\n result=%d",result);
		       break;
	    case 4:result=a/b;
		       printf("\n result=%d",result);
		       break;	
		case 5:result=a%b;
		       printf("\n result=%d",result);
		       break;	 				 		          
	}
}
