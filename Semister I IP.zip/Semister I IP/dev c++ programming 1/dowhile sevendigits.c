#include<stdio.h>
main()
{
	int x,i=1,sum,m;
	int n;
	printf("Enter a 7 didgit number\n");
	scanf("%d",&n);
	m=n;
    do
    {
        sum=sum+n%10;
        n=n/10;
    }while(n>0);
	m=m%1000;
	m=m/100;
	sum=sum-m;
	m=m*m*m;
	if(m==sum)
	{
    	printf("VALID");
	}
	else
	{
		printf("NOT VALID");
	}
}
