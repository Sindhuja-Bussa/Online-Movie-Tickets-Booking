#include<stdio.h>
main()
{
	float i,n;
	float sum;
	printf("enter n:");
	scanf("%f",&n);
	for(i=1,sum=0;i<=n;i++)
	{
		sum=sum+(1.0/i);
	}
	printf("sum=%f",sum);
}
