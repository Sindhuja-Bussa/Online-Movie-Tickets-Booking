#include<stdio.h>
struct details
{
	char first_name[100];
	char last_name[100];
	long long int aadhar_number;
	long long int credit_number;
	int expiry_month;
	int expiry_year;
	int card_id;
	long long int contact_number;
};
void location();
main()
{
	 location();
	 struct details p; 	 
	 printf("ENTER THE FOLLOWING DETAILS:\n FIRST NAME \n LAST NAME \n AADHAR NUMBER \n CREDIT NUMBER \n EXPIRY MONTH \n EXPIRY YEAR \n  CARD ID \n CONTACT NUMBER");	 
	 scanf("%s %s %lld %lld %d %d %d %lld",p.first_name,p.last_name,&p.aadhar_number,&p.credit_number,&p.expiry_month,&p.expiry_year,&p.card_id,&p.contact_number);
	 printf("%s\n%s\n %lld\n %lld\n%d/%d \n %d \n %lld",p.first_name,p.last_name,p.aadhar_number,p.credit_number,p.expiry_month,p.expiry_year,&p.card_id,&p.contact_number);  
}
void location()
{
	printf("\t \t \t \t \t \t \tWELCOME TO ONLINE MOVIE TICKET BOOKING \t \t \t \t \t  ");
	int c,t1,t2,t3,s;
	printf("\n SELECT CITY");
	printf("\n\t \t 1:WARANGAL \n\t \t 2:HANAMKONDA \n \t \t 3:KAZIPET");
	scanf("%d",&c);
	switch(c)
	{
		case 1:
			printf("\n SELECT THEATRE");
			printf("\n\t \t  1:PVR CINEMAS \n\t \t  2:ASIAN GEMINI \n\t \t  3:RAM LAXMAN \n\t \t  4:RADHIKA");
			scanf("%d",&t1);
			switch(t1)
			{
				case 1:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:DR STRANGE \n\t \t  4:F3");
					scanf("%d",&s);	
					break;
					
				case 2:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:DR STRANGE \n\t \t  4:F3");
					scanf("%d",&s);
					break;
				
				case 3:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:F3");
					scanf("%d",&s);
					break;
					
				case 4:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:KGF-2 \n\t \t  2:F3");
					scanf("%d",&s);	
					break;					
			}
		break;
		case 2:
		    printf("\n SELECT THEATRE");
			printf("\n\t \t  1:ASIAN SRIDEVI MULTIPLEX \n\t \t  2:ASHOKA \n\t \t  3:AMRUTHA");
		    scanf("%d",&t2);
			switch(t2)
			{
				case 1:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:DR STRANGE \n\t \t  4:F3");
					scanf("%d",&s);
					break;
				
				case 2:
					printf("\n SELECT MOVIE");
			     	printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:F3");	
					scanf("%d",&s);
					break;
					
				case 3:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:KGF-2 \n\t \t  2:F3");
					scanf("%d",&s);	
					break;							
			}
			break;
		case 3:
		    printf("\n SELECT THEATRE");
			printf("\n\t \t  1:BHAVANI\n\t \t  2:SHAMBHAVI");
			scanf("%d",&t3);
			switch(t3)
			{
				case 1:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:RRR \n\t \t  2:KGF-2 \n\t \t  3:F3");
					scanf("%d",&s);
					break;
					
				case 2:
					printf("\n SELECT MOVIE");
					printf("\n\t \t  1:KGF-2 \n\t \t  2:F3");
					scanf("%d",&s);
					break;									
			}   	
	}
}
